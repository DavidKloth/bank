package test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class paymentTest {

	@Test
	void test() {
		
		bank test = new bank("Test", 1000,5,2);
		
		double cost = test.checkCost(5, 1000, 2);
		
		// Kollar om den totala kostnaden är större än vad lånet är
		
		assertTrue(1000< cost *(2*12));
		
		// Kollar att kostnaden från en extern sida SAMBLA för ett lån på 5000 med 6.59 i ränta och en betalning på 2 år
		// blir den samma som för detta programm. 
		 assertEquals(test.checkCost(6.59, 5000, 2), 222);
		
		
	}

}
