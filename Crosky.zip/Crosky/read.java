import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class read {



 
        
    ArrayList <bank> bankArr = new ArrayList<>();


    public ArrayList <bank> reader(){

        BufferedReader reader;

        try{
            reader = new BufferedReader(new FileReader("prospects.txt"));

            String line = reader.readLine();
            line = reader.readLine();

            while(line != null){

                String name;
                double loan;
                double intrest;
                double year;

               

                ArrayList<String> test = new ArrayList<>();

               String[] arr = line.split(",");
              
               

               if(arr.length == 0){

               }
               else
               {
                if(arr.length > 4){
                    name = arr[0] + " " + arr[1];
                   
                    loan = Double.parseDouble(arr[2]);
                    intrest = Double.parseDouble(arr[3]);
                    year = Double.parseDouble(arr[4]);
                    bank newCustomer = new bank(name,loan,intrest,year);
                    bankArr.add(newCustomer);
                }
                else if (arr.length >1){
                    
                    name = arr[0];
                    loan = Double.parseDouble(arr[1]);
                    intrest = Double.parseDouble(arr[2]);
                    year = Double.parseDouble(arr[3]);
                    bank newCustomer = new bank(name,loan,intrest,year);
                    bankArr.add(newCustomer);
 
                }
                
               }
                line = reader.readLine();
                
            }
            reader.close();
        } catch(IOException e){
            e.printStackTrace();
        }

        return bankArr;

    }
     
    
    
    
    
}
